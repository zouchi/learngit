﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Globalization;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);//导入ini有关写函数
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);//导入ini读函数
        string FileName = System.AppDomain.CurrentDomain.BaseDirectory + "control.ini";
        StringBuilder temp = new StringBuilder(255);//存储读出ini内容
        /****************定义变量*******************/
        int[] available_com = new int[20];//存储可用com端口
        string[] week_str = new string[7]{"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
        byte convert_year, convert_month, convert_day, convert_week, convert_hour, convert_minute,convert_second;
        bool alarm1 = true;
        bool alarm2 = true;
        /****************命令接口******************/
        const byte sync_time = 0x06;
        const byte reset = 0x99;
        const byte clear_count = 0x0a;
        const byte set_alarm1 = 0x02;
        const byte alarm1_off = 0x03;
        const byte set_alarm2 = 0x04;
        const byte alarm2_off = 0x05;
        /*****************************************/
        //bool isbutton = false;

        private void Form1_Load(object sender, EventArgs e)
        {
            add_available_com_to_combobox();//初始化，寻找可用端口
            init_combobox_data();
            GetPrivateProfileString("Data", "Port", "COM" + available_com[0].ToString(), temp, 255, FileName);//从ini文件中读取值
            comboBox1.Text = temp.ToString();
            serialPort1.PortName = temp.ToString();
            checkBox1.Checked = true;
        }

        private void init_combobox_data()
        {
            int i;
            for (i = 10; i < 100; i++)
            {
                comboBox2.Items.Add("20" + i.ToString() + "年");//下拉列表年的初始化
            }
            for (i = 1; i < 13; i++)
            {
                comboBox3.Items.Add(i.ToString() + "月");//下拉列表月初始化
            }
            for (i = 0; i < 24; i++)
            {
                comboBox5.Items.Add(add_zero(i));
                comboBox8.Items.Add(add_zero(i));//初始化小时下拉列表
            }
            for (i = 0; i < 60; i++)
            {
                comboBox6.Items.Add(add_zero(i));
                comboBox7.Items.Add(add_zero(i));//初始化分钟下拉列表
            }
            comboBox2.Text = System.DateTime.Now.Year.ToString() + "年";
            comboBox3.Text = System.DateTime.Now.Month.ToString() + "月";
            comboBox4.Text = System.DateTime.Now.Day.ToString() + "日";
            comboBox5.Text = comboBox8.Text = add_zero(System.DateTime.Now.Hour);
            comboBox6.Text = comboBox7.Text = add_zero(System.DateTime.Now.Minute);
            day();
            comboBox9.Text = comboBox10.Text = "开";
            //System.DateTime
        }

        private string add_zero(int a)
        {
            string str;
            if (a.ToString().Length == 1)
                str = "0" + a.ToString();
            else
                str = a.ToString();
            return str;
        }

        private void day()
        { 
            int i,day = 0;
            switch(comboBox3.Text){//月份天数
                case "1月":
                    day = 31;
                    break;
                case "2月":
                    if (System.DateTime.IsLeapYear(Convert.ToInt32(comboBox2.Text.Substring(0,4),10)))//判断是否为闰年
                        day = 29;
                    else
                        day = 28;
                    break;
                case "3月":
                    day = 31;
                    break;
                case "4月":
                    day = 30;
                    break;
                case "5月":
                    day = 31;
                    break;
                case "6月":
                    day = 30;
                    break;
                case "7月":
                    day = 31;
                    break;
                case "8月":
                    day = 31;
                    break;
                case "9月":
                    day = 30;
                    break;
                case "10月":
                    day = 31;
                    break;
                case "11月":
                    day = 30;
                    break;
                case "12月":
                    day = 31;
                    break;
                default:
                    break;
            }
            for(i=1;i<day + 1;i++)
            {
                comboBox4.Items.Add(i.ToString() + "日");//加入选项列表
            }
        }

        private void add_available_com_to_combobox()//检测可用端口函数
        {
            int i,j;
            for (i = 1,j = 0; i < 21; i++)//最多支持COM1--COM20
            {
                try//使用try{}catch{}语句判断可用端口
                {
                    serialPort1.PortName = "COM" + i.ToString();
                    serialPort1.Open();
                    serialPort1.Close();
                    comboBox1.Items.Add("COM" + i.ToString());//将可用端口存入数据表
                    available_com[j] = i;//顺序存入变量
                    j++;
                }
                catch {
                    continue;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)//打开端口、关闭端口
        {
            if (serialPort1.IsOpen)//判断端口为开还是关 
            {
                button1.Text = "打开端口";//更改按钮文字
                serialPort1.Close();//关闭端口
            }
            else
            {
                 try
                {
                    serialPort1.Open();//打开端口
                    button1.Text = "关闭端口";//更改文字
                    WritePrivateProfileString("Data", "Port", comboBox1.Text.ToString(), FileName);//记录端口
                }
                catch {
                    MessageBox.Show("无效端口，请检查","提示");//错误提示
                    button1.Text = "打开端口";//更改文字
                }
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            day();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            day();
        }

        private void send_order(byte a1, byte a2, byte a3, byte a4, byte a5, byte a6, byte a7, byte a8, byte a9, byte a10)//发送数据函数
        {
            byte[] send_data = new byte[11];
            send_data[0] = clear_count;
            send_data[1] = a1;
            send_data[2] = a2;
            send_data[3] = a3;
            send_data[4] = a4;
            send_data[5] = a5;
            send_data[6] = a6;
            send_data[7] = a7;
            send_data[8] = a8;
            send_data[9] = a9;
            send_data[10] = a10;
            try
            {
                serialPort1.Write(send_data, 0, 11);//发送数据
            }
            catch {
                MessageBox.Show("端口错误，请检查端口","错误");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            send_order(0x01, 0x01, 0, 0, 0, 0, 0, 0, 0, 0);//即时闭合指令
        }

        private void button3_Click(object sender, EventArgs e)
        {
            send_order(0x01, 0x02, 0, 0, 0, 0, 0, 0, 0, 0);//即时关断指令
        }

        private void button7_Click(object sender, EventArgs e)
        {
            send_order(0,0,0,0,0,0,0,0,clear_count,reset);//硬件复位指令
        }

        private void convert_time(string Year,string Month,string Day,string Week,string Hour,string Minute,string Second)
        {
            byte i;//
            for (i = 0; i < 7; i++)
            {
                if (System.DateTime.Now.DayOfWeek.ToString() == week_str[i])
                {
                    convert_week = i;//得到星期(RX8025底层属性)
                    break;
                }
            }
            convert_year = Convert.ToByte(Year.Substring(2, 2), 16);//处理年
            if (Month.Length == 1) Month = Month + "月";
            convert_month = Convert.ToByte(Month.Substring(0, Month.Length - 1), 16);//处理月
            if (Day.Length == 1) Day = Day + "日";
            convert_day = Convert.ToByte(Day.Substring(0, Day.Length - 1), 16);//处理日
            convert_hour = Convert.ToByte(Hour, 16);//处理小时
            convert_minute = Convert.ToByte(Minute, 16);//处理分钟
            convert_second = Convert.ToByte(Second,16);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            convert_time(System.DateTime.Now.Year.ToString(), System.DateTime.Now.Month.ToString(), System.DateTime.Now.Day.ToString(), System.DateTime.Now.DayOfWeek.ToString(), System.DateTime.Now.Hour.ToString(), System.DateTime.Now.Minute.ToString(), System.DateTime.Now.Second.ToString());
            send_order(sync_time, convert_year, convert_month, convert_day, convert_week, convert_hour, convert_minute, convert_second, 0, 0);//发送时间
        }

        private void button4_Click(object sender, EventArgs e)
        {
            convert_time(comboBox2.Text, comboBox3.Text, comboBox4.Text, System.DateTime.Now.DayOfWeek.ToString(), comboBox5.Text, comboBox6.Text, System.DateTime.Now.Second.ToString());
            if(alarm1)
                send_order(set_alarm1, convert_year, convert_month, convert_day, convert_hour, convert_minute, 1, 0, 0, 0);//发送时间
            else
                send_order(alarm1_off, convert_year, convert_month, convert_day, convert_hour, convert_minute, 0, 0, 0, 0);//发送时间
        }

        private void button5_Click(object sender, EventArgs e)
        {
            convert_time(System.DateTime.Now.Year.ToString(), System.DateTime.Now.Month.ToString(), System.DateTime.Now.Day.ToString(), System.DateTime.Now.DayOfWeek.ToString(), comboBox8.Text, comboBox7.Text, System.DateTime.Now.Second.ToString());
            if (alarm2)
            {
                if (checkBox1.Checked)
                    send_order(set_alarm2, convert_hour, convert_minute, 1, 0, 0, 0, 0, 0, 0);//发送时间
                else
                    send_order(set_alarm2, convert_hour, convert_minute, 0, 0, 0, 0, 0, 0, 0);//发送时间
            }
            else
            {
                if (checkBox1.Checked)
                    send_order(alarm2_off, convert_hour, convert_minute, 1, 0, 0, 0, 0, 0, 0);//发送时间
                else
                    send_order(alarm2_off, convert_hour, convert_minute, 0, 0, 0, 0, 0, 0, 0);//发送时间
            }
        }

        private void comboBox10_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox10.Text == "开")//定时器使能开关
                alarm1 = true;
            else
                alarm1 = false;
        }

        private void comboBox9_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox9.Text == "开")//定时器使能开关
                alarm2 = true;
            else
                alarm2 = false;
        }
    }
}
