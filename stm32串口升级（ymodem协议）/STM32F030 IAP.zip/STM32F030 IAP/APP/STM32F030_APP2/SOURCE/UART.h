#ifndef _UART_H_
#define _UART_H_

void Uart1_Init(void);
void Uart1_NVIC_Configuration(void);

#endif
