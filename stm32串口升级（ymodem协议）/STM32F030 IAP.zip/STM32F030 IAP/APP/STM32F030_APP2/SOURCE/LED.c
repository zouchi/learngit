#include "LED.h"
#include "stm32f0xx.h"




void KEY_PC0_Input_Init()
{
   GPIO_InitTypeDef GPIO_InitStructure;
	
	 EXTI_InitTypeDef   EXTI_InitStructure;
	 NVIC_InitTypeDef   NVIC_InitStructure;
	
	 RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, ENABLE);
	 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_3;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
   GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
   GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;//��������  
   GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
	
	 SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOC, EXTI_PinSource0);
	
  /* Configure EXTI0 line */
	 EXTI_InitStructure.EXTI_Line = EXTI_Line0;
	 EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	 EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	 EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	 EXTI_Init(&EXTI_InitStructure);

	 /* Enable and set EXTI0 Interrupt */
	 NVIC_InitStructure.NVIC_IRQChannel = EXTI0_1_IRQn;
	 NVIC_InitStructure.NVIC_IRQChannelPriority = 0x03;
	 NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	 NVIC_Init(&NVIC_InitStructure);
}

void KEY_PC12_Input_Init()
{
   GPIO_InitTypeDef GPIO_InitStructure;
	
	 EXTI_InitTypeDef   EXTI_InitStructure;
	 NVIC_InitTypeDef   NVIC_InitStructure;
	
	 RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, ENABLE);
	 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_3;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
   GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
   GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;//��������  
   GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
	
	 SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOC, EXTI_PinSource12);
	
  /* Configure EXTI0 line */
	 EXTI_InitStructure.EXTI_Line = EXTI_Line12;
	 EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	 EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	 EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	 EXTI_Init(&EXTI_InitStructure);

	 /* Enable and set EXTI0 Interrupt */
	 NVIC_InitStructure.NVIC_IRQChannel = EXTI4_15_IRQn;
	 NVIC_InitStructure.NVIC_IRQChannelPriority = 0x00;
	 NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	 NVIC_Init(&NVIC_InitStructure);
}

void KEY_PA4_Input_Init()
{
   GPIO_InitTypeDef GPIO_InitStructure;
	
	 EXTI_InitTypeDef   EXTI_InitStructure;
	 NVIC_InitTypeDef   NVIC_InitStructure;
	
	 RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
	 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_3;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
   GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
   GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;//��������  
   GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
	
	 SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource4);
	
  /* Configure EXTI0 line */
	 EXTI_InitStructure.EXTI_Line = EXTI_Line4;
	 EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	 EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	 EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	 EXTI_Init(&EXTI_InitStructure);

	 /* Enable and set EXTI0 Interrupt */
	 NVIC_InitStructure.NVIC_IRQChannel = EXTI4_15_IRQn;
	 NVIC_InitStructure.NVIC_IRQChannelPriority = 0x01;
	 NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	 NVIC_Init(&NVIC_InitStructure);
}

void KEY_PB7_Input_Init()
{
   GPIO_InitTypeDef GPIO_InitStructure;
	
	 EXTI_InitTypeDef   EXTI_InitStructure;
	 NVIC_InitTypeDef   NVIC_InitStructure;
	
	 RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
	 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_3;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
   GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
   GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;//��������  
   GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
	
	 SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource7);
	
  /* Configure EXTI0 line */
	 EXTI_InitStructure.EXTI_Line = EXTI_Line7;
	 EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	 EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	 EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	 EXTI_Init(&EXTI_InitStructure);

	 /* Enable and set EXTI0 Interrupt */
	 NVIC_InitStructure.NVIC_IRQChannel = EXTI4_15_IRQn;
	 NVIC_InitStructure.NVIC_IRQChannelPriority = 0x02;
	 NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	 NVIC_Init(&NVIC_InitStructure);
}

void KEY_PB12_Input_Init()
{
   GPIO_InitTypeDef GPIO_InitStructure;
	
	 EXTI_InitTypeDef   EXTI_InitStructure;
	 NVIC_InitTypeDef   NVIC_InitStructure;
	
	 RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
	 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_3;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
   GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
   GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;//��������  
   GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
	
	 SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource12);
	
  /* Configure EXTI0 line */
	 EXTI_InitStructure.EXTI_Line = EXTI_Line12;
	 EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	 EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	 EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	 EXTI_Init(&EXTI_InitStructure);

	 /* Enable and set EXTI0 Interrupt */
	 NVIC_InitStructure.NVIC_IRQChannel = EXTI4_15_IRQn;
	 NVIC_InitStructure.NVIC_IRQChannelPriority = 0x02;
	 NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	 NVIC_Init(&NVIC_InitStructure);
}

void KEY_PB14_Input_Init()
{
   GPIO_InitTypeDef GPIO_InitStructure;
	
	 EXTI_InitTypeDef   EXTI_InitStructure;
	 NVIC_InitTypeDef   NVIC_InitStructure;
	
	 RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
	 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_3;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
   GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
   GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;//��������  
   GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
	
	 SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource14);
	
  /* Configure EXTI0 line */
	 EXTI_InitStructure.EXTI_Line = EXTI_Line14;
	 EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	 EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	 EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	 EXTI_Init(&EXTI_InitStructure);

	 /* Enable and set EXTI0 Interrupt */
	 NVIC_InitStructure.NVIC_IRQChannel = EXTI4_15_IRQn;
	 NVIC_InitStructure.NVIC_IRQChannelPriority = 0x02;
	 NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	 NVIC_Init(&NVIC_InitStructure);
}

void LED_PC8_Init()
{
   GPIO_InitTypeDef GPIO_InitStructure;
	 RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, ENABLE);
	 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_3;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
   GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
   GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;//��������  
   GPIO_Init(GPIOC, &GPIO_InitStructure);
}


