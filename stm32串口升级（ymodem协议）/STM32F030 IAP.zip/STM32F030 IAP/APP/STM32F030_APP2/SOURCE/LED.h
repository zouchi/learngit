#ifndef _LED_H_
#define _LED_H_

#include "stm32f0xx.h"

void delay(uint32_t i);
void HSIInit(void);
void KEY_PB14_Input_Init(void);
void KEY_PA4_Input_Init(void);
void KEY_PC0_Input_Init(void);
void KEY_PC12_Input_Init(void);

void KEY_PB7_Input_Init(void);
void KEY_PB12_Input_Init(void);

void LED_PC8_Init(void);
void Toggle_LED();


#define  RCC_CFGR_PLLSRC_HSI_DIV2    ((uint32_t)0x00000000)        /*!< HSI clock divided by 2 selected as PLL entry clock source */
#endif
