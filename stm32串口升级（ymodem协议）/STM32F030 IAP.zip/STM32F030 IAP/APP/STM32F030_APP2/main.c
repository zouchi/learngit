/**********************************************************************
 *����˵����STM32F0 IAP TEST
 *@author:Jeremy.he@foxmail.net
 *@date:2014-06-25
 *********************************************************************/


#include "LED.h"
#include "UART.h"
#include "stm32f0xx.h"

#define APPLICATION_ADDRESS     ((uint32_t)0x08003000)


#define LED_OFF                       GPIOC->BSRR = 0x2000//GPIO_ResetBits(GPIOC,GPIO_Pin_13)
#define LED_ON                        GPIOC->BRR = 0x2000 //GPIO_SetBits(GPIOC,GPIO_Pin_13)
#define LED_TURN                      GPIOC->ODR ^= 0x2000




void LED_Init(void);
void IAP_Set()
{
   uint32_t i = 0;

/* Relocate by software the vector table to the internal SRAM at 0x20000000 ***/  

  /* Copy the vector table from the Flash (mapped at the base of the application
     load address 0x08003000) to the base address of the SRAM at 0x20000000. */       
  for(i = 0; i < 48; i++)
  {
    *((uint32_t*)(0x20000000 + (i << 2)))=*(__IO uint32_t*)(APPLICATION_ADDRESS + (i<<2));
	}
  /* Enable the SYSCFG peripheral clock*/ 
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE); 
	
	/* Remap SRAM at 0x00000000 */
  SYSCFG_MemoryRemapConfig(SYSCFG_MemoryRemap_SRAM);
	
	
	
	
}	



void LED_Init(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
  
  RCC_AHBPeriphClockCmd( RCC_AHBPeriph_GPIOC, ENABLE);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOC, &GPIO_InitStructure);

 
}

void delay(uint32_t i)
{
   uint32_t a,b;
	 for(a=0;a<i;a++)
	   for(b=0;b<2000;b++);
}


void Toggle_LED()
{

      GPIO_SetBits(GPIOC,GPIO_Pin_13);
	    delay(1000);		 
	    GPIO_ResetBits(GPIOC,GPIO_Pin_13);
	    delay(1000);
}



int main()
{ IAP_Set();
	
  LED_Init();
	while(1)
	{
		Toggle_LED();
	}
}

